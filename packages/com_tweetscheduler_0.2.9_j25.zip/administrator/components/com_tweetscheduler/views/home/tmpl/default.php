<?php
/*
 * Joomla! component TweetScheduler
 *
 * @author Yireo (info@yireo.com)
 * @package TweetScheduler
 * @copyright Copyright 2011
 * @license GNU Public License
 * @link http://www.yireo.com
 */

defined('_JEXEC') or die('Restricted access');
?>
<table id="adminform" width="100%">
<tr>
<td width="60%" valign="top">

<div id="cpanel">
<?php include_once 'default_cpanel.php'; ?>
<div class="version">
    <?php echo JText::sprintf('Current version', $this->current_version); ?><span style="float:left;" id="latest_version"></span><br/>
    <?php echo JText::_('See our online tutorials for help'); ?>:<br/>
    <a href="<?php echo $this->urls['tutorials']; ?>"><?php echo $this->urls['tutorials']; ?></a>
</div>
<div class="review">
    <?php echo JText::sprintf('Do you like', 'TweetScheduler'); ?><br/>
    <?php echo JText::_('Help us with your review or vote on the official JED website'); ?><br/>
    <a href="<?php echo $this->urls['jed']; ?>"><?php echo $this->urls['jed']; ?></a>
</div>
<div class="twitter">
    <?php echo JText::_('Follow us on Twitter'); ?>:<br/>
    <a href="<?php echo $this->urls['twitter']; ?>"><?php echo $this->urls['twitter']; ?></a>
</div>
<div class="facebook">
    <?php echo JText::_('Follow us on Facebook'); ?>:<br/>
    <a href="<?php echo $this->urls['facebook']; ?>"><?php echo $this->urls['facebook']; ?></a>
</div>
</div>

</td>
<td width="40%" valign="top" style="margin-top:0; padding:0">
<?php include_once 'default_ads.php'; ?>
</td>
</tr>
</table>
