<?php
/**
 * Joomla! component TweetScheduler
 *
 * @author Yireo
 * @copyright Copyright 2012
 * @license GNU Public License
 * @link http://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

// Include the parent
require_once JPATH_COMPONENT.'/helpers/shortener.php';

class TweetSchedulerHelperShortenerTinyurl extends TweetSchedulerHelperShortener
{
    protected $_title = 'TinyURL';

    public function shorten($url)
    {
        if (preg_match('/http:\/\/(bit.ly|goo.gl|tinyurl.com)/', $url)) return $url;

        $lookupUrl = 'http://tinyurl.com/api-create.php?url='.$url;
        $data = YireoHelper::fetchRemote($lookupUrl);
        return $data;
    }
}
