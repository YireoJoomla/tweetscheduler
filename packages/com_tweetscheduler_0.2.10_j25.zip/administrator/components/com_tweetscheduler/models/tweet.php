<?php
/*
 * Joomla! component TweetScheduler
 *
 * @author Yireo (info@yireo.com)
 * @copyright Copyright Yireo.com 2012
 * @license GNU Public License
 * @link http://www.yireo.com
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

/*
 * TweetScheduler Tweet model
 */
class TweetSchedulerModelTweet extends YireoModel
{
    /**
     * Override the orderby_title
     *
     * @var string
     */
    protected $_orderby_title = 'message';

    /**
     * Constructor method
     *
     * @access public
     * @param null
     * @return null
     */
    public function __construct()
    {
        parent::__construct('tweet');
    }

    /**
     * Method to store the model
     *
     * @access public
     * @subpackage Yireo
     * @param mixed $data
     * @return bool
     */
    public function store($data)
    {
        // Flatten the account_id
        if(is_array($data['account_id'])) {
            $data['account_id'] = implode(',',$data['account_id']);
        }
        
        // Shorten the URLs in the message
        if($this->params->get('autoshorten', 1) == 1 && !empty($data['message'])) {
            require_once JPATH_COMPONENT_ADMINISTRATOR.'/helpers/shortener.php';
            $data['message'] = TweetSchedulerHelperShortener::autoshortenText($data['message']);
        }

        return parent::store($data);
    }

    /**
     * Override buildQuery method
     *
     * @access protected
     * @param null
     * @return string
     */
    protected function buildQuery($query = '')
    {
        $query = "SELECT {tableAlias}.*, category.title AS category_name, category.url AS category_url, ";
        $query .= " editor.name AS editor FROM {table} AS {tableAlias} ";
        $query .= " LEFT JOIN #__tweetscheduler_categories AS category ON {tableAlias}.category_id = category.id ";
        $query .= " LEFT JOIN #__users AS editor ON {tableAlias}.checked_out = editor.id ";
        return parent::buildQuery($query);
    }

    /**
     * Method to modify the data once it is loaded
     *
     * @access protected
     * @param array $data
     * @return array
     */
    protected function onDataLoad($data)
    {
        if(is_string($data->account_id)) {
            $data->account_id = explode(',', trim($data->account_id));
        }

        if(!empty($data->account_id)) {
            $db = JFactory::getDBO();
            $query = 'SELECT * FROM #__tweetscheduler_accounts WHERE `id` IN ('.implode(',', $data->account_id).')';
            $db->setQuery($query);
            $data->accounts = $db->loadObjectList();
        }

        return $data;
    }

    /**
     * Method to post a twitter-message
     *
     * @access public
     * @param array $data
     * @return string
     */
    public function postTwitter($data)
    {
        // Get the object
        $twitter = TweetSchedulerHelper::getTwitter($data);

        // Post the data
        $twitterInfo = $twitter->post_statusesUpdate(array('status' => $data->message));
        return $twitterInfo->response;
    }

    /**
     * Method to post a facebook-message
     *
     * @access public
     * @param array $data
     * @return string
     */
    public function postFacebook($data)
    {
        // Get the object
        $facebook = TweetSchedulerHelper::getFacebook($data);
        $user = $facebook->getUser();
        if(!$user > 0) {
            return array('error' => 'Unable to login into Facebook');
        }

        // Post the data
        $post = array(
            'message' => $data->message,
            'name' => $data->title,
            'caption' => $data->title,
            'image' => null, // @todo: Create a specific field for this
            'link' => $data->category_url,
            'actions' => array(array('name' => $data->category_name, 'link' => $data->category_url)),
        );
        $result = $facebook->api('/me/feed/', 'post', $post);
        return $result;
    }

    /**
     * Method to post a Linkedin-message
     *
     * @access public
     * @param array $data
     * @return string
     */
    public function postLinkedin($data)
    {
        // Get the object
        $linkedin = TweetSchedulerHelper::getLinkedin($data);

        // Post the data
        $content = array(
            'title' => $data->title,
            'description' => $data->message,
            'submitted-url' => $data->category_url,
            //'submitted-image-url' => null,
        );

        try {
            $response = $linkedin->share('new', $content, false);
        } catch (Exception $e) {
            $response = array(
                'error' => $e->getMessage(),
                'debug' => $linkedin->debugInfo,
            );
        }

        return $response;
    }

    /**
     * Generic method to post a message
     *
     * @access public
     * @param array $data
     * @return string
     */
    public function post($data)
    {
        // Set default variables
        $rt = false;
        $post_state = 0;
        $post_id = array();
        $post_error = array();

        // Prepare the data a bit more
        if(empty($data->title)) $data->title = $data->category_name;

        // Loop through the accounts
        if(!empty($data->accounts)) {
            foreach($data->accounts as $account) {

                // Merge the data with the account
                $account = (object)array_merge((array)$account, (array)$data);
                unset($account->accounts);
                unset($account->account_id);

                // Post the data
                switch($account->type) {
                    case 'facebook':
                        $response = $this->postFacebook($account);
                        break;

                    case 'linkedin':
                        $response = $this->postLinkedin($account);
                        break;

                    default:
                        $response = $this->postTwitter($account);
                        break;
                }

                // Set the variables
                if (!empty($response['id'])) {
                    $post_state = 1;
                    $post_id[] = $response['id'];
                    $rt = true;

                } elseif (!empty($response['success']) && $response['success'] == 1) {
                    $post_state = 1;
                    $rt = true;

                } else if (!empty($response['error'])) {
                    $post_error = $response['error'];

                } elseif(!empty($response['errors'][0]['message'])) {
                    $post_error = $response['errors'][0]['message'];

                } else {
                    $post_error = 'Unknown response';
                }
            }
        }

        // Run the query
        $db = JFactory::getDBO();
        $post_state = (int)$post_state;
        $post_id = $db->Quote(implode('|', $post_id));
        $post_error = $db->Quote(implode('|', $post_error));
        $query = "UPDATE #__tweetscheduler_tweets SET post_state = ".$post_state.", post_id = ".$post_id.", post_error = ".$post_error." WHERE id = ".(int)$data->id;
        $db->setQuery($query);
        $db->query();

        // Duplicate this tweet
        if($rt == true && !empty($data->params)) {
            $params = YireoHelper::toRegistry($data->params);
            $reschedule = $params->get('reschedule');
            if(!empty($reschedule)) {
                $this->duplicate($data, $reschedule);
            }
        }

        return $response;
    }

    /**
     * Method to duplicate a message
     *
     * @access public
     * @param array $data
     * @param string $reschedule
     * @return boolean
     */
    public function duplicate($data, $reschedule)
    {
        $model = new self;
        $model->setId(0);

        $old_post_date = $data->post_date;
        $new_post_date = TweetSchedulerHelper::getRescheduleTime($old_post_date, $reschedule);

        $data->id = 0;
        $data->post_date = $new_post_date;

        $data = JArrayHelper::fromObject($data);
        $data['params'] = array(
            'reschedule' => $reschedule,
        );
        return $model->store($data);
    }
}
