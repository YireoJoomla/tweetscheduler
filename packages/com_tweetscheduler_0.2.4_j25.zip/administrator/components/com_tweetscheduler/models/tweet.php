<?php
/*
 * Joomla! component TweetScheduler
 *
 * @author Yireo (info@yireo.com)
 * @copyright Copyright Yireo.com 2012
 * @license GNU Public License
 * @link http://www.yireo.com
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

// Require the parent model
require_once JPATH_COMPONENT_ADMINISTRATOR.'/lib/model.php';

/*
 * TweetScheduler Tweet model
 */
class TweetSchedulerModelTweet extends YireoModel
{
    /**
     * Override the orderby_title
     *
     * @var string
     */
    protected $_orderby_title = 'message';

    /**
     * Constructor method
     *
     * @access public
     * @param null
     * @return null
     */
    public function __construct()
    {
        parent::__construct('tweet');
    }

    /**
     * Method to store the model
     *
     * @access public
     * @subpackage Yireo
     * @param mixed $data
     * @return bool
     */
    public function store($data)
    {
        if($this->params->get('autoshorten', 1) == 1 && !empty($data['message'])) {
            require_once JPATH_COMPONENT.'/helpers/shortener.php';
            $data['message'] = TweetSchedulerHelperShortener::autoshortenText($data['message']);
        }

        return parent::store($data);
    }

    /**
     * Override buildQuery method
     *
     * @access protected
     * @param null
     * @return string
     */
    protected function buildQuery($query = '')
    {
        $query = "SELECT {tableAlias}.*, category.title AS category_name, category.url AS category_url, account.consumer_key, account.consumer_secret, account.oauth_token, account.oauth_token_secret, editor.name AS editor FROM {table} AS {tableAlias} ";
        $query .= " LEFT JOIN #__tweetscheduler_categories AS category ON {tableAlias}.category_id = category.id ";
        $query .= " LEFT JOIN #__tweetscheduler_accounts AS account ON {tableAlias}.account_id = account.id ";
        $query .= " LEFT JOIN #__users AS editor ON {tableAlias}.checked_out = editor.id ";
        return parent::buildQuery($query);
    }
}
