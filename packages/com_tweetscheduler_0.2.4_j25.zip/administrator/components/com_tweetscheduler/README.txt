
1) Register a new account under http://twitter.com/oauth per website where you want to use TweetScheduler
    Application name = Joomla! TweetScheduler (unique name!)
    Description = TweetScheduler
    Application website = http://example.com/
    Organization = Yireo
    Website = http://example.com/
    Application Type = Browser (*)
    Callback URL = http://www.yireo.com/administrator/index.php?option=com_tweetscheduler&view=account&task=accountConfirm (*)
    Default Access type: Read & Write (*)
    Use Twitter for login = No

Feedback:
2) Enter consumer key and secret in 
Consumer key: YQieIaiUINKKmXbNsHkhQ
Consumer secret: kD5IXFbiSQJuijnn21jMM457RJs46eIfWhAVzU8eZ4g

3) Cronjob
    wget -O - "http://www.yireo.com/index.php?option=com_tweetscheduler" >/dev/null 2>&1
