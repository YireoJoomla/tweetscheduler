<?php
/**
 * Joomla! component TweetScheduler
 *
 * @author Yireo (info@yireo.com)
 * @package TweetScheduler
 * @copyright Copyright 2012
 * @license GNU Public License
 * @link http://www.yireo.com
 */

// Check to ensure this file is included in Joomla!  
defined('_JEXEC') or die();

// Require the parent view
require_once JPATH_COMPONENT.'/lib/view.php';

/**
 * HTML View class 
 *
 * @static
 * @package TweetScheduler
 */
class TweetSchedulerViewCategory extends YireoView
{
    /*
     * Display method
     *
     * @param string $tpl
     * @return null
     */
    public function display($tpl = null)
    {
        $sourceUrl = JRequest::getString('url');
        $shortenerCode = JRequest::getString('shortener');
        $newUrl = null;

        require_once JPATH_COMPONENT.'/helpers/shortener.php';
        $shorteners = TweetSchedulerHelperShortener::getShorteners();
        if(isset($shorteners[$shortenerCode])) {
            $shortener = $shorteners[$shortenerCode];
            if(!empty($shortener)) {
                print $shortener->shorten($sourceUrl);
            }
        }

        $application = JFactory::getApplication();
        $application->close();
        exit;
    }
}
