<?php
/**
 * Joomla! component TweetScheduler
 *
 * @author Yireo
 * @copyright Copyright 2012
 * @license GNU Public License
 * @link http://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

class TweetSchedulerHelper 
{
    static public function initTwitterApi()
    {
        // Include the Epi-libraries
        require_once JPATH_COMPONENT_ADMINISTRATOR.'/lib/twitter/EpiCurl.php';
        require_once JPATH_COMPONENT_ADMINISTRATOR.'/lib/twitter/EpiOAuth.php';
        require_once JPATH_COMPONENT_ADMINISTRATOR.'/lib/twitter/EpiTwitter.php';
    }

    static public function initFacebookApi()
    {
        require_once JPATH_ADMINISTRATOR.'/components/com_tweetscheduler/lib/facebook/facebook.php';
    }

    static public function initLinkedinApi()
    {
        require_once JPATH_ADMINISTRATOR.'/components/com_tweetscheduler/lib/linkedin/linkedin.php';
    }

    static public function getTwitter($data)
    {
        // Initialize the API
        TweetSchedulerHelper::initTwitterApi();

        // Initialize the twitter-object with the given data
        $twitter = new EpiTwitter($data->consumer_key, $data->consumer_secret, $data->oauth_token, $data->oauth_token_secret);

        return $twitter;
    }

    static public function getFacebook($data)
    {
        // Initialize the API
        TweetSchedulerHelper::initFacebookApi();

        // Initialize the facebook-object
        $facebook = new Facebook(array(
          'appId' => $data->consumer_key,
          'secret' => $data->consumer_secret,
        ));

        if(!empty($data->oauth_token_secret)) $facebook->setAppSecret($data->oauth_token_secret);
        if(!empty($data->oauth_token)) $facebook->setAccessToken($data->oauth_token);
        return $facebook;
    }

    static public function getLinkedin($data)
    {
        // Initialize the API
        TweetSchedulerHelper::initLinkedinApi();

        $config = array(
            'appKey' => $data->consumer_key,
            'appSecret' => $data->consumer_secret,
            'callbackUrl' => $_SERVER['REQUEST_URI'],
        );

        $linkedin = new LinkedIn($config);
        $linkedin->setResponseFormat('JSON');
        $response = $linkedin->retrieveTokenRequest();

        //$oauth = new OAuthConsumer($data->consumer_key, $data->consumer_secret);
        $linkedin->setToken(array('oauth_token' => $data->oauth_token, 'oauth_token_secret' => $data->oauth_token_secret));

        return $linkedin;
    }

    static public function post($data)
    {
        require_once JPATH_ADMINISTRATOR.'/components/com_tweetscheduler/models/tweet.php';
        $model = new TweetSchedulerModelTweet();
        return $model->post($data);
    }

    /*
     * Fetch a list of categories
     *
     * @param string $tpl
     * @return null
     */
	static public function getCategoryOptions($include_null = false)
	{
        $db = JFactory::getDBO();
        $db->setQuery('SELECT `title`,`id` AS `value`,`url` FROM #__tweetscheduler_categories ORDER BY ordering');
        $rows = $db->loadObjectList();
        if ($include_null) {
            $option = array('title' => '-- Select --', 'value' => 0);
            array_unshift($rows, $option);
        }
        return $rows;
	}

    /*
     * Fetch a list of accounts
     *
     * @param string $tpl
     * @return null
     */
	static public function getAccountOptions($include_null = false)
	{
        $db = JFactory::getDBO();
        $db->setQuery('SELECT `title`, `type`, `id` AS `value` FROM #__tweetscheduler_accounts ORDER BY ordering');
        $rows = $db->loadObjectList();
        foreach($rows as $rowIndex => $row) {
            $row->title = $row->title.' ['.$row->type.']';
            $rows[$rowIndex] = $row;
        }

        if ($include_null) {
            $option = array('title' => '-- Select --', 'value' => 0);
            array_unshift($rows, $option);
        }
        return $rows;
	}

    /*
     * Fetch a list of types
     *
     * @param string $tpl
     * @return null
     */
	static public function getTypeOptions($include_null = false)
	{
        $rows = array(
            array('title' => JText::_('Twitter'), 'value' => 'twitter'), 
            array('title' => JText::_('Facebook'), 'value' => 'facebook'), 
            array('title' => JText::_('LinkedIn'), 'value' => 'linkedin'), 
        );

        if ($include_null) {
            $option = array('title' => '-- Select --', 'value' => null);
            array_unshift($rows, $option);
        }
        return $rows;
	}

    /*
     * Fetch a list of accounts
     *
     * @param string $tpl
     * @return null
     */
	static public function getPostStateOptions($include_null = false)
	{
        $rows = array(
            array('title' => JText::_('Pending'), 'value' => 0), 
            array('title' => JText::_('Posted'), 'value' => 1), 
        );

        if ($include_null) {
            $option = array('title' => '-- Select --', 'value' => null);
            array_unshift($rows, $option);
        }
        return $rows;
	}

    /*
     * Method to return the extra seconds for a specific string
     *
     * @param mixed $timestring
     * @return string
     */
	static public function getRescheduleTime($current_time, $reschedule_time)
    {
        if(preg_match('/^([0-9]+)([a-z]+)/', $reschedule_time, $match)) {
            $new_time = strtotime('+'.$match[1].' '.$match[2], strtotime($current_time));
            return date('Y-m-d H:i:s', $new_time);
        }

        return $current_time;
    }

    /*
     * Method to format the time
     *
     * @param mixed $timestring
     * @return string
     */
	static public function formatTime($time)
    {
        $timestamp = strtotime($time);
        $seconds = $timestamp - time();

        $time_string = null;
        if($seconds == 0) {
            $time_string = 'now';
        } elseif($seconds > 0) {
            $minutes = round($seconds / 60);
            $hours = round($seconds / 60 / 60);
            $days = round($seconds / 60 / 60 / 24);
            if($minutes < 2) {
                $time_string = $minutes.' minute';
            } elseif($minutes < 60) {
                $time_string = $minutes.' minutes';
            } elseif($hours == 1) {
                $time_string = $hours.' hour';
            } elseif($hours < 24) {
                $time_string = $hours.' hours';
            } elseif($days == 1) {
                $time_string = $days.' day';
            } else {
                $time_string = $days.' days';
            }
        } else {
            $minutes = round((0 - $seconds) / 60);
            $hours = round((0 - $seconds) / 60 / 60);
            $days = round((0 - $seconds) / 60 / 60 / 24);
            if($minutes < 2) {
                $time_string = $minutes.' minute ago';
            } elseif($minutes < 60) {
                $time_string = $minutes.' minutes ago';
            } elseif($hours == 1) {
                $time_string = $hours.' hour ago';
            } elseif($hours < 24) {
                $time_string = $hours.' hours ago';
            } elseif($days == 1) {
                $time_string = $days.' day ago';
            } else {
                $time_string = $days.' days ago';
            }
        }

        return $time_string;
    }
}
