<?php
/**
 * Joomla! component TweetScheduler
 *
 * @author Yireo (info@yireo.com)
 * @copyright Copyright 2012
 * @license GNU Public License
 * @link http://www.yireo.com
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// Load the libraries
require_once JPATH_COMPONENT_ADMINISTRATOR.'/helpers/helper.php';
        
// Load common variables
$db = JFactory::getDBO();
$app = JFactory::getApplication();

// Fetch the remaining tweets
require_once JPATH_COMPONENT_ADMINISTRATOR.'/models/tweets.php';
$model = new TweetSchedulerModelTweets();
$model->addWhere('post_date < NOW()');
$model->addWhere('post_state = 0');
$tweets = $model->getData();

if (!empty($tweets)) {
    foreach ($tweets as $tweet) {

        // Get the twitter object
        $twitter = TweetSchedulerHelper::getTwitter($tweet);

        // Post the tweet
        $twitterInfo = $twitter->post_statusesUpdate(array('status' => $tweet->message));
        $response = $twitterInfo->response;

        // Build an update query
        if (!empty($response['id'])) {
            $query = "UPDATE #__tweetscheduler_tweets SET post_state = 1, post_id = ".$db->Quote($response['id'])." WHERE id = ".(int)$tweet->id;
            $db->setQuery($query);
            $db->query();
        } else if (!empty($response['error'])) {
            $query = "UPDATE #__tweetscheduler_tweets SET post_error = ".$db->Quote($response['error'])." WHERE id = ".(int)$tweet->id;
            $db->setQuery($query);
            $db->query();
        }
    }
}

$app->close();
