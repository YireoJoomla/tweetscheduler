<?php
/*
 * Joomla! component TweetScheduler
 *
 * @author Yireo (info@yireo.com)
 * @copyright Copyright 2012
 * @license GNU Public License
 * @link http://www.yireo.com
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Require the parent model
require_once JPATH_COMPONENT_ADMINISTRATOR.'/lib/table.php';

/**
* Tweet Table class
*/
class TableTweet extends YireoTable
{
    /**
     * Constructor
     *
     * @access public
     * @param JDatabase $db
     * @return null
     */
    public function __construct(& $db)
    {
        // Initialize the fields
        $this->_fields = array(
            'id' => null,
            'account_id' => null,
            'category_id' => null,
            'message' => null,
            'post_date' => date('Y-m-d H:m', strtotime('+1 hour')),
            'post_state' => 0,
            'post_id' => 0,
            'post_error' => null,
        );

        // Set the required fields
        $this->_required = array(
            'message',
            'account_id',
            'category_id',
        );

        // Call the constructor
        parent::__construct('#__tweetscheduler_tweets', 'id', $db);
    }

    /**
     * Overloaded check method to ensure data integrity
     *
     * @access public
     * @subpackage Yireo
     * @param null
     * @return bool
     */
    public function check()
    {
        // Perform the parent-checks
        $result = parent::check();
        if($result == false) return false;

        // Append the category URL to this message 
        if($this->category_id) {
            $query = "SELECT url FROM #__tweetscheduler_categories WHERE id = ".(int)$this->category_id;
            $db = JFactory::getDBO();
            $db->setQuery($query);
            $category_url = $db->loadResult();
            if(!empty($category_url) && !strstr($this->message, $category_url)) {
                $this->message .= ' '.$category_url;
            }
        }

        // Check whether the message does not exceed the maximum 
        $too_many_chars = 140 - strlen($this->message);
        if($too_many_chars < 0) {
			$this->_error = sprintf('Message exceeds maximum length by %d characters', 0 - $too_many_chars);
            return false;
        }

        return true;
    }
}
