<?php
/*
 * Joomla! component TweetScheduler
 *
 * @author Yireo (info@yireo.com)
 * @copyright Copyright Yireo.com 2012
 * @license GNU Public License
 * @link http://www.yireo.com
 */

// Check to ensure this file is included in Joomla!  
defined('_JEXEC') or die();

// Require the parent model
require_once JPATH_COMPONENT_ADMINISTRATOR.'/lib/model.php';

/*
 * TweetScheduler Tweets model
 */
class TweetSchedulerModelTweets extends YireoModel
{
    /**
     * Constructor method
     *
     * @access public
     * @param null
     * @return null
     */
    public function __construct()
    {
        parent::__construct('tweet');

        $category_id = $this->getFilter('category_id');
        if($category_id > 0) {
            $this->addWhere('category_id = '.$category_id);
        }

        $account_id = $this->getFilter('account_id');
        if($account_id > 0) {
            $this->addWhere('account_id = '.$account_id);
        }

        $this->_search = array('message');
        $this->_orderby_default = 'post_date';
    }

    /**
     * Override buildQuery method
     *
     * @access protected
     * @param null
     * @return string
     */
    protected function buildQuery($query = '')
    {
        $query = "SELECT {tableAlias}.*, category.title AS category_name, account.title AS account_name, account.consumer_key, account.consumer_secret, account.oauth_token, account.oauth_token_secret, editor.name AS editor FROM {table} AS {tableAlias} ";
        $query .= " LEFT JOIN #__tweetscheduler_categories AS category ON {tableAlias}.category_id = category.id ";
        $query .= " LEFT JOIN #__tweetscheduler_accounts AS account ON {tableAlias}.account_id = account.id ";
        $query .= " LEFT JOIN #__users AS editor ON {tableAlias}.checked_out = editor.id ";
        return parent::buildQuery($query);
    }
}
