<?php
/*
 * Joomla! component TweetScheduler
 *
 * @author Yireo (info@yireo.com)
 * @copyright Copyright 2012
 * @license GNU Public License
 * @link http://www.yireo.com
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

// Include the parent controller
require_once JPATH_COMPONENT.'/lib/controller.php';

/**
 * TweetScheduler Controller
 */
class TweetSchedulerController extends YireoController
{
    /**
     * Constructor
     * @package TweetScheduler
     */
    public function __construct()
    {
        $this->_default_view = 'home';
        parent::__construct();
    }

    public function redirectAuthorize()
    {
        // Set the view manually
        JRequest::setVar('view', 'account');

        // Fetch the model-data        
        $model = $this->_loadModel();
        $data = $model->getData();

        // If the consumer_key and/or consumer_secret are not valid, redirect to the form
        if (empty($data->consumer_key) || empty($data->consumer_secret)) {
        }

        // Initialize the twitter-objects
        TweetSchedulerHelper::initTwitterApi();
        $twitter = new EpiTwitter($data->consumer_key, $data->consumer_secret);
        $token = $twitter->getRequestToken();

        // Save the token in the model
        $data->oauth_token = $token->oauth_token;
        $model->store((array)$data);
        
        // Redirect to twitter authorization
        $this->setRedirect($twitter->getAuthorizationUrl());
    }

    public function accountConfirm()
    {
        // Set the view manually
        JRequest::setVar('view', 'account');

        // Get the GET-data from Twitter
        $oauth_token = JRequest::getCmd('oauth_token');
        $oauth_verifier = JRequest::getCmd('oauth_verifier');

        // Load the saved data
        $db = JFactory::getDBO();
        $db->setQuery('SELECT * FROM #__tweetscheduler_accounts WHERE oauth_token='.$db->Quote($oauth_token));
        $data = $db->loadObject();
        if (empty($data)) {
        }

        // Fetch the model-data        
        $model = $this->_loadModel();
        $model->setId($data->id);

        // Get the twitter object
        $twitter = TweetSchedulerHelper::getTwitter($data);

        // Handle 
        $token = $twitter->getAccessToken();
        $twitter->setToken($token->oauth_token, $token->oauth_token_secret);

        // Add the new data to the model-data
        $data->oauth_token_secret = $token->oauth_token_secret;
        $data->oauth_token = $token->oauth_token;

        // Save the token in the model
        if ($model->store((array)$data) == false) {
            $this->msg = $model->getError();
            $this->msg_type = 'error';
            $this->doRedirect('accounts');
            return;
        }
        
        // Fetch the screen_name
        $twitterInfo = $twitter->get_accountVerify_credentials();
        $twitterInfo->response;
        $twitter_account = $twitterInfo->screen_name;

        // Give feedback to the Joomla! application
        $this->msg = JText::sprintf('Twitter-account "%s" is authorised', $twitter_account);
        $this->doRedirect('accounts');
    }

    public function test()
    {
        // Set the view manually
        JRequest::setVar('view', 'account');

        // Fetch the model-data        
        $model = $this->_loadModel();
        $data = $model->getData();

        // Get the twitter object
        $twitter = TweetSchedulerHelper::getTwitter($data);

        // Handle 
        $twitterInfo = $twitter->get_accountVerify_credentials();
        $twitterInfo->response;

        // Fetch the screen_name
        $twitter_account = $twitterInfo->screen_name;

        // Give feedback to the Joomla! application
        if (empty($twitter_account)) {
            $this->msg = JText::_('Twitter authentication failed');
            $this->msg_type = 'error';
        } else {
            $this->msg = JText::sprintf('Twitter-account is set to "%s"', $twitter_account);
        }
        $this->doRedirect('accounts');
    }

    public function send()
    {
        // Fetch the model-data        
        $model = $this->_loadModel();
        $tweet = $model->getData();

        // Get the twitter object
        $twitter = TweetSchedulerHelper::getTwitter($tweet);

        // Post the tweet
        $twitterInfo = $twitter->post_statusesUpdate(array('status' => $tweet->message));
        $response = $twitterInfo->response;

        // Build an update query
        $db = JFactory::getDBO();
        if (!empty($response['id'])) {
            $query = "UPDATE #__tweetscheduler_tweets SET post_state = 1, post_id = ".$db->Quote($response['id'])." WHERE id = ".(int)$tweet->id;
            $db->setQuery($query);
            $db->query();
        } else if (!empty($response['error'])) {
            $query = "UPDATE #__tweetscheduler_tweets SET post_error = ".$db->Quote($response['error'])." WHERE id = ".(int)$tweet->id;
            $db->setQuery($query);
            $db->query();
        }

        // Give feedback to the Joomla! application
        if (empty($response)) {
            $this->msg = JText::_('Twitter-update failed');
            $this->msg_type = 'error';
        } else if (!empty($response['error'])) {
            $this->msg = JText::sprintf('Twitter-update failed: %s', $response['error']);
            $this->msg_type = 'error';
        } else {
            $this->msg = JText::_('Twitter-update was successful');
        }

        $this->doRedirect('tweets');
    }
}
