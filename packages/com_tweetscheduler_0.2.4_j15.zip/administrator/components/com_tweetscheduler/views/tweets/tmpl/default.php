<?php
/*
 * Joomla! component TweetScheduler
 *
 * @author Yireo (info@yireo.com)
 * @copyright Copyright 2012
 * @license GNU Public License
 * @link http://www.yireo.com
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');
?>
<form method="post" name="adminForm" id="adminForm">
<table>
<tr>
    <td align="left" width="100%">
        <?php echo $this->search; ?>
    </td>
    <td nowrap="nowrap">
        <?php echo $this->lists['category_filter']; ?>
        <?php echo $this->lists['account_filter']; ?>
    </td>
</tr>
</table>

<div id="editcell">
    <table class="adminlist">
    <thead>
        <tr>
            <th width="5">
                <?php echo JText::_( 'NUM' ); ?>
            </th>
            <th width="20">
                <input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $this->items ); ?>);" />
            </th>
            <th class="title">
                <?php echo JHTML::_('grid.sort',  'Message', 'tweet.message', $this->lists['order_Dir'], $this->lists['order'] ); ?>
            </th>
            <th width="10">
                <?php echo JText::_('Chars'); ?>
            </th>
            <th width="150" class="title">
                <?php echo JHTML::_('grid.sort',  'Category', 'tweet.category_id', $this->lists['order_Dir'], $this->lists['order'] ); ?>
            </th>
            <th width="150" class="title">
                <?php echo JHTML::_('grid.sort',  'Account', 'tweet.account_id', $this->lists['order_Dir'], $this->lists['order'] ); ?>
            </th>
            <th width="200" class="title">
                <?php echo JHTML::_('grid.sort',  'Post on', 'tweet.post_date', $this->lists['order_Dir'], $this->lists['order'] ); ?>
            </th>
            <th width="5%" class="title">
                <?php echo JHTML::_('grid.sort',  'Post state', 'tweet.post_state', $this->lists['order_Dir'], $this->lists['order'] ); ?>
            </th>
            <th width="5%" nowrap="nowrap">
                <?php echo JHTML::_('grid.sort',  'State', 'tweet.state', $this->lists['order_Dir'], $this->lists['order'] ); ?>
            </th>
            <th width="200" class="title">
                <?php echo JText::_('Actions'); ?>
            </th>
            <th width="1%" nowrap="nowrap">
                <?php echo JHTML::_('grid.sort',  'ID', 'tweet.id', $this->lists['order_Dir'], $this->lists['order'] ); ?>
            </th>
        </tr>
    </thead>
    <tfoot>
        <tr>
            <td colspan="11">
                <?php echo $this->pagination->getListFooter(); ?>
            </td>
        </tr>
    </tfoot>
    <tbody>
    <?php
    $k = 0;
    if( count( $this->items ) > 0 ) {
        for ($i=0, $n=count( $this->items ); $i < $n; $i++)
        {
            $item = &$this->items[$i];
            $edit_url = 'index.php?option=com_tweetscheduler&view=tweet&id='.$item->id;
            $send_url = 'index.php?option=com_tweetscheduler&view=tweet&task=send&id='.$item->id;
            $checked = JHTML::_('grid.checkedout', $item, $i );
            $published = JHTML::_('grid.published', $item, $i );

            $item_timestamp = strtotime($item->post_date);
            $seconds = $item_timestamp - time();
            if($seconds == 0) {
                $time_string = 'now';
            } elseif($seconds > 0) {
                $minutes = round($seconds / 60);
                $hours = round($seconds / 60 / 60);
                $days = round($seconds / 60 / 60 / 24);
                if($minutes < 2) {
                    $time_string = $minutes.' minute';
                } elseif($minutes < 60) {
                    $time_string = $minutes.' minutes';
                } elseif($hours == 1) {
                    $time_string = $hours.' hour';
                } elseif($hours < 24) {
                    $time_string = $hours.' hours';
                } elseif($days == 1) {
                    $time_string = $days.' day';
                } else {
                    $time_string = $days.' days';
                }
            } else {
                $minutes = round((0 - $seconds) / 60);
                $hours = round((0 - $seconds) / 60 / 60);
                $days = round((0 - $seconds) / 60 / 60 / 24);
                if($minutes < 2) {
                    $time_string = $minutes.' minute ago';
                } elseif($minutes < 60) {
                    $time_string = $minutes.' minutes ago';
                } elseif($hours == 1) {
                    $time_string = $hours.' hour ago';
                } elseif($hours < 24) {
                    $time_string = $hours.' hours ago';
                } elseif($days == 1) {
                    $time_string = $days.' day ago';
                } else {
                    $time_string = $days.' days ago';
                }
            }
                
            $item->post_date .= ' ('.$time_string.')';

            $actions = array();
            $actions[$edit_url] = 'Edit';
            $actions[$send_url] = 'Post Tweet';
            ?>
            <tr class="<?php echo "row$k"; ?>">
                <td>
                    <?php echo $this->pagination->getRowOffset( $i ); ?>
                </td>
                <td>
                    <?php echo $checked; ?>
                </td>
                <td>
                    <a href="<?php echo $edit_url; ?>" title="<?php echo JText::_( 'Edit tweet' ); ?>"><?php echo $item->message; ?></a>
                </td>
                <td>
                    <?php echo strlen($item->message); ?>
                </td>
                <td>
                    <?php echo $item->category_name; ?>
                </td>
                <td>
                    <?php echo $item->account_name; ?>
                </td>
                <td>
                    <?php echo $item->post_date; ?>
                </td>
                <td>
                    <?php echo ($item->post_state == 1) ? JText::_('Posted') : JText::_('Pending'); ?>
                </td>
                <td align="center">
                    <?php echo $published; ?>
                </td>
                <td>
                    <?php foreach($actions as $url => $action) { ?>
                    <a href="<?php echo $url; ?>" title="<?php echo $action; ?>"><?php echo $action; ?></a> &nbsp; | &nbsp;
                    <?php } ?>
                </td>
                <td align="center">
                    <?php echo $item->id; ?>
                </td>
            </tr>
            <?php
            $k = 1 - $k;
        }
    } else {
        ?>
        <tr>
        <td colspan="11">
            <?php echo JText::_( 'No items' ); ?>
        </td>
        </tr>
        <?php
    }
    ?>
    </tbody>
    </table>
</div>

<?php echo $this->hidden_fields; ?>
</form>

