<?php
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

/*
http://api.linkedin.com/v1/people/~/network/updates
https://www.linkedin.com/secure/developer
"Add New Application"
 */

// http://code.google.com/p/simple-linkedinphp/

$apiKey = '19cdh044myvg';
$secretKey = 'eu10X34qUjwUw7WK';
$oauth_user_token = '8396c435-1749-46cc-987b-ee1721ebb77b';
$oauth_secret_token = '5d6ee1b4-e832-4652-929a-8a2af376004e';
  
require_once('linkedin_3.2.0.class.php');

// Fill the keys and secrets you retrieved after registering your app
$config = array(
    'appKey' => $apiKey,
    'appSecret' => $secretKey,
    'callbackUrl' => $_SERVER['REQUEST_URI'],
);
$linkedin = new LinkedIn($config);
$response = $linkedin->retrieveTokenRequest();

$oauth = new OAuth($apiKey, $secretKey);
$oauth->setToken($oauth_user_token, $oauth_secret_token);

?>
<pre>
<?php
// Retreive own profile-data
/*$url = "http://api.linkedin.com/v1/people/~?format=json";
$oauth->fetch($url, array(), OAUTH_HTTP_METHOD_GET, array());
$data = $oauth->getLastResponse();
$data = json_decode($data);
print_r($data);
*/

$data = array(
    'comment' => 'Checkout our Yireo TrashCan extension',
    'content' => array(
        'title' => 'TrashCan extension for Magento',
        'description' => 'An extension that offers a way to restore Magento products, when you accidently deleted them.',
        'submitted-url' => 'http://www.yireo.com/software/magento-extensions/trashcan',
    ),
    'visibility' => array(
        'code' => 'anyone',
    ),
);

$url = 'http://api.linkedin.com/v1/people/~/shares';

$headers = array(
    'Content-Type' => 'application/json',
    'x-li-format' => 'json',
);

try {
    $oauth->fetch( $url, json_encode($data), OAUTH_HTTP_METHOD_POST, $headers );
    $response = json_decode( $oauth->getLastResponse() );
    $response->response_info = (object) $oauth->getLastResponseInfo();
    $response->success = (int)($response->response_info->http_code < 300);
} catch (Exception $e) {
    print_r($e->getMessage()) . "\n";
    print_r($oauth->debugInfo) . "\n";
    die();
}

print_r($response);
