/*
 * Joomla! component TweetScheduler
 *
 * @author Yireo (info@yireo.com)
 * @package TweetScheduler
 * @copyright Copyright 2011
 * @link http://www.yireo.com
 */

function maximumChars(text, maxChars, charsLeft_id, messageWarning_id)  {
    
    var textArea = $(text);

    // create a custom focused property so that we only capture keystrokes when it is
    textArea.addEvents({
        focus: function() {
            this.focused = true;
        },
        blur: function() {
            this.focused = false;
        }
    });
    
    // attach a key listener
    window.addEvent('keyup', function(e) {
        if (textArea.focused) {

            var chars = textArea.value.trim().length;
            $(charsLeft_id).innerHTML = chars;

            if (chars+1 >= maxChars) {
                $(messageWarning_id).innerHTML = 'Limit reached';
            } else {
                $(messageWarning_id).innerHTML = '';
            }
        }
    });
}
