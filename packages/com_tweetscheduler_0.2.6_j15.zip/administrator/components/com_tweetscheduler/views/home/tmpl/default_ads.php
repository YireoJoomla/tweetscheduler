<?php
/*
 * Joomla! component TweetScheduler
 *
 * @author Yireo (info@yireo.com)
 * @package TweetScheduler
 * @copyright Copyright 2012
 * @license GNU Public License
 * @link http://www.yireo.com
 */

defined('_JEXEC') or die('Restricted access');
?>
<?php if($this->backend_feed == 1) { ?>
<h2 class="promotion_header"><?php echo JText::_('Yireo focus'); ?></h2>
<div id="promotion">
    <div class="loader" />
</div>
<h2 class="latest_news_header"><?php echo JText::_('Latest blog from Yireo'); ?></h2>
<div id="latest_news">
    <div class="loader" />
</div>
<?php } ?>
