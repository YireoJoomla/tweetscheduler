http://joomla25.yireo.dev/administrator/components/com_tweetscheduler/lib/linkedin/test.php

http://api.linkedin.com/v1/people/~/network/updates

https://www.linkedin.com/secure/developer
"Add New Application"

