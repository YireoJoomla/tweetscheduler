<?php
/*
 * Joomla! component Tweetscheduler
 *
 * @author Yireo (info@yireo.com)
 * @copyright Copyright 2014
 * @license GNU Public License
 * @link http://www.yireo.com
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

/**
 * Account View class
 */
class TweetschedulerViewAccount extends YireoViewForm
{
    /*
     * Display method
     *
     * @param string $tpl
     * @return null
     */
	public function display($tpl = null)
	{
        $this->fetchItem();
        $this->lists['type'] = JHTML::_('select.genericlist', TweetschedulerHelper::getTypeOptions(), 'type', null, 'value', 'title', $this->item->type);
		parent::display($tpl);
    }
}
