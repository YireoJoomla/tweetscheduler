<?php
/**
 * Joomla! component TweetScheduler
 *
 * @author Yireo
 * @copyright Copyright 2013
 * @license GNU Public License
 * @link http://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

// Do not automatically generate all columns
$auto_columns = false;

// Define the actions            
$actions = array();
$actions['index.php?option=com_tweetscheduler&view=tweet&id='.$item->id] = JText::_('LIB_YIREO_VIEW_EDIT');
$actions['index.php?option=com_tweetscheduler&view=tweet&task=send&id='.$item->id] = JText::_('COM_TWEETSCHEDULER_POST_TWEET');
?>
<td>
    <?php if ($this->isCheckedOut($item)) { ?>
        <span class="checked_out"><?php echo $item->message; ?></span>
    <?php } else { ?>
        <a href="<?php echo $item->edit_link; ?>" title="<?php echo JText::_('LIB_YIREO_VIEW_EDIT'); ?>"><?php echo $item->message; ?></a>
    <?php } ?>
</td>
<td>
    <?php echo strlen($item->message); ?>
</td>
<td>
    <?php echo $item->category_name; ?>
</td>
<td>
    <?php if(!empty($item->accounts)) : ?>
        <?php foreach($item->accounts as $account) : ?>
            <?php echo $account->title; ?> [<?php echo $account->type; ?>]<br/>
        <?php endforeach; ?>
    <?php else: ?>
        <?php echo JText::_('LIB_YIREO_VIEW_LIST_NO_ITEMS'); ?> 
    <?php endif; ?>
</td>
<td>
    <?php echo $item->post_date; ?>
    (<?php echo TweetSchedulerHelper::formatTime($item->post_date); ?>)
</td>
<td>
    <?php echo ($item->post_state == 1) ? JText::_('LIB_YIREO_POSTED') : JText::_('LIB_YIREO_PENDING'); ?>
</td>
<td align="center">
    <?php echo $published; ?>
</td>
<td>
    <?php foreach($actions as $url => $action) { ?>
    <a href="<?php echo $url; ?>" title="<?php echo $action; ?>"><?php echo $action; ?></a> &nbsp; | &nbsp;
    <?php } ?>
</td>
<td align="center">
    <?php echo $item->id; ?>
</td>
