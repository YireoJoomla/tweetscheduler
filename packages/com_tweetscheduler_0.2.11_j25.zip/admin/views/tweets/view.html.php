<?php
/*
 * Joomla! component TweetScheduler
 *
 * @author Yireo (info@yireo.com)
 * @copyright Copyright 2013
 * @license GNU Public License
 * @link http://www.yireo.com
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

/**
 * HTML View class
 */
class TweetSchedulerViewTweets extends YireoViewList
{
    /*
     * Display method
     *
     * @param string $tpl
     * @return null
     */
    public function display($tpl = null)
    {
        // Add clean-button to toolbar
        JToolBarHelper::custom('deletePosted','delete.png','delete.png', 'Clean posted', false);

        // Create select-filters
        $javascript = 'onchange="document.adminForm.submit();"';
        $this->lists['category_filter'] = JHTML::_('select.genericlist', TweetSchedulerHelper::getCategoryOptions(true), 'filter_category_id', $javascript, 'value', 'title', $this->getFilter('category_id'));
        $this->lists['account_filter'] = JHTML::_('select.genericlist', TweetSchedulerHelper::getAccountOptions(true), 'filter_account_id', $javascript, 'value', 'title', $this->getFilter('account_id'));
        $this->lists['post_state_filter'] = JHTML::_('select.genericlist', TweetSchedulerHelper::getPostStateOptions(true), 'filter_post_state', $javascript, 'value', 'title', $this->getFilter('post_state'));

        parent::display($tpl);
    }
}

