<?php
/*
 * Joomla! component TweetScheduler
 *
 * @author Yireo (info@yireo.com)
 * @copyright Copyright 2011
 * @license GNU Public License
 * @link http://www.yireo.com
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

/**
 * HTML View class
 */
class TweetSchedulerViewTweet extends YireoViewForm
{
    /*
     * Display method
     *
     * @param string $tpl
     * @return null
     */
	public function display($tpl = null)
	{
        YireoHelper::jquery();
        $this->document->addScript( JURI::root().'media/com_tweetscheduler/js/backend.js' ) ;
        $this->fetchItem();

        // Build the fields
        if(!$this->item->category_id > 0) $this->item->category_id = $this->getFilter('category_id', null, null, 'com_tweetscheduler_tweets_');
        $this->lists['category_id'] = JHTML::_('select.genericlist', TweetSchedulerHelper::getCategoryOptions(true), 'category_id', null, 'value', 'title', $this->item->category_id);
        $this->lists['account_id'] = JHTML::_('select.genericlist', TweetSchedulerHelper::getAccountOptions(), 'account_id[]', 'multiple="multiple"', 'value', 'title', $this->item->account_id);
        $this->lists['post_date'] = JHTML::_('calendar', $this->item->post_date, 'post_date', 'post_date', '%Y-%m-%d %H:%M:%S', array('class' => 'inputbox'));
        $this->lists['categories'] = TweetSchedulerHelper::getCategoryOptions();

        if($this->item->post_state == 1) {
            $this->lists['post_state'] = JHTML::_('select.booleanlist', 'post_state', null, $this->item->post_state, 'Posted', 'Pending');
        } else {
            $this->lists['post_state'] = JText::_('Pending');
        }
		parent::display($tpl);
	}

    /*
     * Fetch a list of categories
     *
     * @param string $tpl
     * @return null
     */
	public function getCategoryOptions()
	{
        $db = JFactory::getDBO();
        $db->setQuery('SELECT `title`,`id` AS `value` FROM #__tweetscheduler_categories');
        return $db->loadObjectList();
	}

    /*
     * Fetch a list of accounts
     *
     * @param string $tpl
     * @return null
     */
	public function getAccountOptions()
	{
        $db = JFactory::getDBO();
        $db->setQuery('SELECT `title`,`id` AS `value` FROM #__tweetscheduler_accounts');
        return $db->loadObjectList();
	}
}
