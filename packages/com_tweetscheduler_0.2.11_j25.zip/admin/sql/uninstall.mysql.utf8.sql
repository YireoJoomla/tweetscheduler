DROP TABLE IF EXISTS `#__tweetscheduler_tweets`;
DROP TABLE IF EXISTS `#__tweetscheduler_categories`;
DROP TABLE IF EXISTS `#__tweetscheduler_accounts`;
