<?php
/*
 * Joomla! component TweetScheduler
 *
 * @author Yireo (info@yireo.com)
 * @copyright Copyright 2011
 * @license GNU Public License
 * @link http://www.yireo.com
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

/**
 * Account View class
 */
class TweetSchedulerViewAccount extends YireoViewForm
{
    /*
     * Display method
     *
     * @param string $tpl
     * @return null
     */
	public function display($tpl = null)
	{
        $this->fetchItem();
        $this->lists['type'] = JHTML::_('select.genericlist', TweetSchedulerHelper::getTypeOptions(), 'type', null, 'value', 'title', $this->item->type);
		parent::display($tpl);
    }
}
