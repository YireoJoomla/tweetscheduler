<?php
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

/*
http://joomla25.yireo.dev/administrator/components/com_tweetscheduler/lib/facebook/test.php

0) https://developers.facebook.com/apps
1) Create app
2) [Settings > Basic] Check "Website with Facebook Login"
    Site URL: http://joomla25.yireo.dev/administrator/components/com_tweetscheduler/lib/facebook/test.php
3) [Settings > Basic] 
    Copy "App ID" & "App Secret"

*/
require 'facebook.php';

$facebook = new Facebook(array(
  'appId' => '129110503906570',
  'secret' => '4f45b0493ee10ac527346f055a49fff6',
));
    
$user = $facebook->getUser();
if($user > 0) {
    try {
        $user_profile = $facebook->api('/me');
    } catch(Exception $e) {
        $user = null;
    }
}

if(empty($user)) {
    header('Location: '.$facebook->getLoginUrl());
    exit;
}
  
$logoutUrl = $facebook->getLogoutUrl();
?>
<a href="<?php echo $logoutUrl; ?>">logout</a>
<?php

$attachment = array(
    'message' => 'this is my message',
    'name' => 'This is my demo Facebook application!',
    'caption' => "Caption of the Post",
    'link' => 'http://mylink.com',
    'description' => 'this is a description',
    'picture' => 'http://mysite.com/pic.gif',
    'actions' => array(
        array(
            'name' => 'Get Search',
            'link' => 'http://www.google.com'
        )
    )
);
?>
<pre>
<?php
try {
    $permissions = $facebook->api("/me/permissions");
} catch(Exception $e) {
    echo 'Unable to fetch permissions<br/>';
    die($e->getMessage());
}

if( array_key_exists('publish_stream', $permissions['data'][0]) == false ) {
    //echo 'No permission "publish_stream"<br/>';
    //print_r($permissions);
    header('Location: '.$facebook->getLoginUrl(array('scope' => 'publish_stream')));
    exit;
}

try {
    $result = $facebook->api('/me/feed/', 'post', $attachment);
} catch(Exception $e) {
    echo 'Unable to post to wall<br/>';
    die($e->getMessage());
}

