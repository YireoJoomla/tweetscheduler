<?php
/*
 * Joomla! component TweetScheduler
 *
 * @author Yireo (info@yireo.com)
 * @copyright Copyright 2012
 * @license GNU Public License
 * @link http://www.yireo.com
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

/**
 * TweetScheduler Controller
 */
class TweetSchedulerController extends YireoController
{
    /**
     * Constructor
     * @package TweetScheduler
     */
    public function __construct()
    {
        $this->_default_view = 'home';
        parent::__construct();
    }

    public function redirectAuthorize()
    {
        // Set the view manually
        JRequest::setVar('view', 'account');

        // Fetch the model-data        
        $model = $this->_loadModel();
        $data = $model->getData();

        // If the consumer_key and/or consumer_secret are not valid, redirect to the form
        if (empty($data->consumer_key) || empty($data->consumer_secret)) {
            $this->msg = 'No consumer-key and consumer-secret configured';
            $this->msg_type = 'error';
            $this->doRedirect('accounts');
            return false;
        }

        // Initialize the twitter-objects
        TweetSchedulerHelper::initTwitterApi();

        // Initialize the twitter-client
        try {
            $twitter = new EpiTwitter($data->consumer_key, $data->consumer_secret);
        } catch(Exception $e) {
            $this->msg = $e->getMessage();
            $this->msg_type = 'error';
            $this->doRedirect('accounts');
            return false;
        }

        // Set the callback
        /*try {
            $twitter->setCallback(JRoute::_('index.php?option=com_tweetscheduler&view=account&task=accountConfirm'));
        } catch(Exception $e) {
            $this->msg = $e->getMessage();
            $this->msg_type = 'error';
            $this->doRedirect('accounts');
            return false;
        }*/

        // Get the request-token
        try {
            $token = $twitter->getRequestToken();
        } catch(Exception $e) {
            $this->msg = $e->getMessage();
            $this->msg_type = 'error';
            $this->doRedirect('accounts');
            return false;
        }

        // Save the token in the model
        $data->oauth_token = $token->oauth_token;
        $data->oauth_token_secret = $token->oauth_token_secret;
        $model->store((array)$data);
        
        // Get the authorization URL
        try {
            $twitterUrl = $twitter->getAuthorizationUrl();
        } catch(Exception $e) {
            $this->msg = $e->getMessage();
            $this->msg_type = 'error';
            $this->doRedirect('accounts');
            return false;
        }

        // Redirect to twitter authorization
        $this->setRedirect($twitterUrl);
    }

    public function accountConfirm()
    {
        // Set the view manually
        JRequest::setVar('view', 'account');

        // Get the GET-data from Twitter
        $oauth_token = JRequest::getCmd('oauth_token');

        // If these details are empty, manual configuration is needed
        if(empty($oauth_token)) {
            $this->msg = 'Don\'t forget to manually configure the OAuth Token and the OAuth Token Secret';
            $this->doRedirect('accounts');
            return false;
        }

        // Load the saved data
        $db = JFactory::getDBO();
        $db->setQuery('SELECT * FROM #__tweetscheduler_accounts WHERE oauth_token='.$db->Quote($oauth_token));
        $data = $db->loadObject();
        if (empty($data)) {
            $this->msg = 'No data found for OAuth-token "'.$oauth_token.'"';
            $this->msg_type = 'error';
            $this->doRedirect('accounts');
            return false;
        }

        // Fetch the model-data        
        $model = $this->_loadModel();
        if(empty($model)) {
            $this->msg = 'Empty model';
            $this->msg_type = 'error';
            $this->doRedirect('accounts');
            return false;
        }

        // Set this model-ID
        $model->setId($data->id);

        // Get the twitter object
        $twitter = TweetSchedulerHelper::getTwitter($data);

        // Handle 
        $twitter->setToken($oauth_token);
        $token = $twitter->getAccessToken();

        // Add the new data to the model-data
        $data->oauth_token_secret = $token->oauth_token_secret;
        $data->oauth_token = $token->oauth_token;

        // Insert the new access-token
        $twitter->setToken($token->oauth_token, $token->oauth_token_secret);

        // Save the token in the model
        if ($model->store((array)$data) == false) {
            $this->msg = $model->getError();
            $this->msg_type = 'error';
            $this->doRedirect('accounts');
            return false;
        }
        
        // Fetch the screen_name
        $twitterInfo = $twitter->get_accountVerify_credentials();
        $twitterInfo->response;
        $twitter_account = $twitterInfo->screen_name;

        // Give feedback to the Joomla! application
        $this->msg = JText::sprintf('Twitter-account "%s" is authorised', $twitter_account);
        $this->doRedirect('accounts');
    }

    public function test()
    {
        // Fetch the model-data        
        $model = $this->_loadModel();
        if(empty($model)) {
            $this->msg = 'Empty model';
            $this->msg_type = 'error';
            $this->doRedirect('accounts');
            return false;
        }

        // Fetch the data
        $data = $model->getData();
        if(empty($data)) {
            $this->msg = 'Empty data';
            $this->msg_type = 'error';
            $this->doRedirect('accounts');
            return false;
        }

        // Get the twitter object
        $twitter = TweetSchedulerHelper::getTwitter($data);

        // Handle the twitter-call
        try {
            $twitterInfo = $twitter->get_accountVerify_credentials();
        } catch(Exception $e) {
            $response = $e->getMessage();
            if(substr($response, 0, 2) == '{"') {
                $response = json_decode($response);
                $error = (string)$response->error;
            } else {
                $error = $response;
            }
            $this->msg = 'API error: '.$error;
            $this->msg_type = 'error';
            $this->doRedirect('accounts');
            return false;
        }

        // @todo: Fetch the response
        $twitterInfo->response;

        // Fetch the screen_name
        $twitter_account = $twitterInfo->screen_name;

        // Give feedback to the Joomla! application
        if (empty($twitter_account)) {
            $this->msg = JText::_('Twitter authentication failed');
            $this->msg_type = 'error';
        } else {
            $this->msg = JText::sprintf('Twitter-account is set to "%s"', $twitter_account);
        }
        $this->doRedirect('accounts');
    }

    public function send()
    {
        // Fetch the model-data        
        $model = $this->_loadModel();
        $tweet = $model->getData();

        // Post the tweet
        $response = TweetSchedulerHelper::post($tweet);

        // Give feedback to the Joomla! application
        if (empty($response)) {
            $this->msg = JText::_('Twitter-update failed');
            $this->msg_type = 'error';
        } else if (!empty($response['error'])) {
            $this->msg = JText::sprintf('Twitter-update failed: %s', $response['error']);
            $this->msg_type = 'error';
        } elseif(!empty($response['errors'][0]['message'])) {
            $this->msg = JText::sprintf('Twitter-update failed: %s', $response['errors'][0]['message']);
            $this->msg_type = 'error';
        } else {
            $this->msg = JText::_('Twitter-update was successful');
        }

        $this->doRedirect('tweets');
    }
}
