<?php
/*
 * Joomla! component TweetScheduler
 *
 * @author Yireo (info@yireo.com)
 * @copyright Copyright Yireo.com 2012
 * @license GNU Public License
 * @link http://www.yireo.com
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

/*
 * TweetScheduler Tweet model
 */
class TweetSchedulerModelTweet extends YireoModel
{
    /**
     * Override the orderby_title
     *
     * @var string
     */
    protected $_orderby_title = 'message';

    /**
     * Constructor method
     *
     * @access public
     * @param null
     * @return null
     */
    public function __construct()
    {
        parent::__construct('tweet');
    }

    /**
     * Method to store the model
     *
     * @access public
     * @subpackage Yireo
     * @param mixed $data
     * @return bool
     */
    public function store($data)
    {
        if($this->params->get('autoshorten', 1) == 1 && !empty($data['message'])) {
            require_once JPATH_COMPONENT.'/helpers/shortener.php';
            $data['message'] = TweetSchedulerHelperShortener::autoshortenText($data['message']);
        }

        return parent::store($data);
    }

    /**
     * Override buildQuery method
     *
     * @access protected
     * @param null
     * @return string
     */
    protected function buildQuery($query = '')
    {
        $query = "SELECT {tableAlias}.*, category.title AS category_name, category.url AS category_url, account.consumer_key, account.consumer_secret, account.oauth_token, account.oauth_token_secret, editor.name AS editor FROM {table} AS {tableAlias} ";
        $query .= " LEFT JOIN #__tweetscheduler_categories AS category ON {tableAlias}.category_id = category.id ";
        $query .= " LEFT JOIN #__tweetscheduler_accounts AS account ON {tableAlias}.account_id = account.id ";
        $query .= " LEFT JOIN #__users AS editor ON {tableAlias}.checked_out = editor.id ";
        return parent::buildQuery($query);
    }

    public function post($data)
    {
        // Get the twitter object
        $twitter = TweetSchedulerHelper::getTwitter($data);

        // Post the data
        $twitterInfo = $twitter->post_statusesUpdate(array('status' => $data->message));
        $response = $twitterInfo->response;

        // Build an update query
        $db = JFactory::getDBO();
        $query = null;
        if (!empty($response['id'])) {
            $query = "UPDATE #__tweetscheduler_tweets SET post_state = 1, post_id = ".$db->Quote($response['id'])." WHERE id = ".(int)$data->id;
            $rt = true;
        } else if (!empty($response['error'])) {
            $query = "UPDATE #__tweetscheduler_tweets SET post_error = ".$db->Quote($response['error'])." WHERE id = ".(int)$data->id;
            $rt = false;
        } elseif(!empty($response['errors'][0]['message'])) {
            $query = "UPDATE #__tweetscheduler_tweets SET post_error = ".$db->Quote($response['errors'][0]['message'])." WHERE id = ".(int)$data->id;
            $rt = false;
        } else {
            $query = "UPDATE #__tweetscheduler_tweets SET post_error = 'Unknown response' WHERE id = ".(int)$data->id;
            $rt = false;
        }

        // Run the query
        if(!empty($query)) {
            $db->setQuery($query);
            $db->query();
        }

        // Duplicate this tweet
        if($rt == true && !empty($data->params)) {
            $params = YireoHelper::toRegistry($data->params);
            $reschedule = $params->get('reschedule');
            if(!empty($reschedule)) {
                $this->duplicate($data, $reschedule);
            }
        }

        return $response;
    }

    public function duplicate($data, $reschedule)
    {
        $model = new self;
        $model->setId(0);

        $old_post_date = $data->post_date;
        $new_post_date = TweetSchedulerHelper::getRescheduleTime($old_post_date, $reschedule);

        $data->id = 0;
        $data->post_date = $new_post_date;

        $data = JArrayHelper::fromObject($data);
        $data['params'] = array(
            'reschedule' => $reschedule,
        );
        return $model->store($data);
    }
}
