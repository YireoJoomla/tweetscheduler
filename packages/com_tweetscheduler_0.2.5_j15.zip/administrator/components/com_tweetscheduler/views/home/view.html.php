<?php
/**
 * Joomla! component TweetScheduler
 *
 * @author Yireo (info@yireo.com)
 * @package TweetScheduler
 * @copyright Copyright 2012
 * @license GNU Public License
 * @link http://www.yireo.com
 */

// Check to ensure this file is included in Joomla!  
defined('_JEXEC') or die();

/**
 * HTML View class 
 *
 * @static
 * @package TweetScheduler
 */
class TweetSchedulerViewHome extends YireoViewHome
{
    /*
     * Display method
     *
     * @param string $tpl
     * @return null
     */
    public function display($tpl = null)
    {
        $icons = array();
        $icons[] = $this->icon( 'tweet&task=add', 'New Tweet', 'new.png', null );
        $icons[] = $this->icon( 'tweets', 'Tweets', 'tweet.png', null );
        $icons[] = $this->icon( 'accounts', 'Accounts', 'user.png', null );
        $icons[] = $this->icon( 'categories', 'Categories', 'category.png', null );
        $this->assignRef( 'icons', $icons );

        $urls = array();
        $urls['twitter'] ='http://twitter.com/yireo';
        $urls['facebook'] ='http://www.facebook.com/yireo';
        $urls['tutorials'] = 'http://www.yireo.com/tutorials/tweetscheduler';
        $urls['jed'] = 'http://extensions.joomla.org/extensions/social-web/social-auto-publish/16753';
        $this->assignRef( 'urls', $urls );

        parent::display($tpl);
    }
}
