<?php
/*
 * Joomla! component TweetScheduler
 *
 * @author Yireo (info@yireo.com)
 * @copyright Copyright 2012
 * @license GNU Public License
 * @link http://www.yireo.com
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');
?>
<form method="post" name="adminForm">
<table>
<tr>
    <td align="left" width="100%">
        <?php echo $this->search; ?>
    </td>
    <td nowrap="nowrap">
    </td>
</tr>
</table>

<div id="editcell">
    <table class="adminlist">
    <thead>
        <tr>
            <th width="5">
                <?php echo JText::_( 'NUM' ); ?>
            </th>
            <th width="20">
                <input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $this->items ); ?>);" />
            </th>
            <th width="250" class="title">
                <?php echo JHTML::_('grid.sort',  'Category Title', 'category.title', $this->lists['order_Dir'], $this->lists['order'] ); ?>
            </th>
            <th width="250" class="title">
                <?php echo JHTML::_('grid.sort',  'Category URL', 'category.url', $this->lists['order_Dir'], $this->lists['order'] ); ?>
            </th>
            <th width="10">
                <?php echo JText::_('Chars'); ?>
            </th>
            <th width="5%" nowrap="nowrap">
                <?php echo JHTML::_('grid.sort',  'Published', 'category.published', $this->lists['order_Dir'], $this->lists['order'] ); ?>
            </th>
			<th width="8%" nowrap="nowrap">
				<?php echo JHTML::_('grid.sort',  'Order', 'category.ordering', $this->lists['order_Dir'], $this->lists['order'] ); ?>
				<?php echo JHTML::_('grid.order',  $this->items ); ?>
			</th>
            <th width="1%" nowrap="nowrap">
                <?php echo JHTML::_('grid.sort',  'ID', 'category.id', $this->lists['order_Dir'], $this->lists['order'] ); ?>
            </th>
        </tr>
    </thead>
    <tfoot>
        <tr>
            <td colspan="11">
                <?php echo $this->pagination->getListFooter(); ?>
            </td>
        </tr>
    </tfoot>
    <tbody>
    <?php
    $k = 0;
    if( count( $this->items ) > 0 ) {
        for ($i=0, $n=count( $this->items ); $i < $n; $i++)
        {
            $item = &$this->items[$i];
            $checked = JHTML::_('grid.checkedout', $item, $i );
            $published = JHTML::_('grid.published', $item, $i );
            $ordering = ($this->lists['order'] == 'category.ordering');
            $url = 'index.php?option=com_tweetscheduler&view=category&cid[]='.$item->id;
            ?>
            <tr class="<?php echo "row$k"; ?>">
                <td>
                    <?php echo $this->pagination->getRowOffset( $i ); ?>
                </td>
                <td>
                    <?php echo $checked; ?>
                </td>
                <td>
                    <a href="<?php echo $url; ?>" title="<?php echo JText::_( 'Edit category' ); ?>"><?php echo $item->title; ?></a>
                </td>
                <td>
                    <a href="<?php echo $item->url; ?>" title="<?php echo $item->title; ?>"><?php echo $item->url; ?></a>
                </td>
                <td>
                    <?php echo strlen($item->url); ?>
                </td>
                <td align="center">
                    <?php echo $published; ?>
                </td>
                <td class="order">
                    <span><?php echo $this->pagination->orderUpIcon( $i, true,'orderup', 'Move Up', $ordering ); ?></span>
                    <span><?php echo $this->pagination->orderDownIcon( $i, 0, true, 'orderdown', 'Move Down', $ordering ); ?></span>
                    <?php $disabled = $ordering ?  '' : 'disabled="disabled"'; ?>
                    <input type="text" name="order[]" size="5" value="<?php echo $item->ordering;?>" <?php echo $disabled ?> class="text_area" style="text-align: center" />
                </td>
                <td align="center">
                    <?php echo $item->id; ?>
                </td>
            </tr>
            <?php
            $k = 1 - $k;
        }
    } else {
        ?>
        <tr>
        <td colspan="11">
            <?php echo JText::_( 'No categories' ); ?>
        </td>
        </tr>
        <?php
    }
    ?>
    </tbody>
    </table>
</div>

<?php echo $this->hidden_fields; ?>
</form>

